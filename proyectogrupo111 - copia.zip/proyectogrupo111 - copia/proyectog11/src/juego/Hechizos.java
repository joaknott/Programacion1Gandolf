package juego;

public class Hechizos {

}
